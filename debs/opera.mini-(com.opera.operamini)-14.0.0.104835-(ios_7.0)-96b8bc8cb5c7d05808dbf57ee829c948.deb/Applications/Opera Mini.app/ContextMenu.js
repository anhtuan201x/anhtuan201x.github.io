// Copyright (C) 2015 Opera Software ASA. All rights reserved.
// This file is an original work developed by Opera Software ASA.

/**
 * @fileoverview
 *
 * The context menu always operates on the element that was the target of the
 * last touch event in the view. JavaScript touch events will fire before the
 * UIWebView is notified about the touch.
 *
 * If the touch originated in a sub frame, the API exposed to the UIWebView
 * might not be allowed to access the touched element directly, due to Cross
 * Origin security policy. Instead, all interesting data about the touched
 * element is gathered and sent via the postMessage API to the top window.
 *
 * If the touch occurred in the top window, any mutator or accessor calls from
 * the UIWebView applies immediately and synchronously to the saved element.
 *
 * If the touch occurred in a sub frame, accessor methods returns the data from
 * the previous postMessage data. Mutating methods will use postMessage to the
 * sub frame in question, requesting to update the element that was previously
 * saved in that sub frame after the JavaScript touch event.
 */
"use strict";

var ContextMenu = exports;

/** @define {boolean} */
var DEBUG = false;

var FocusElementType = require("./enums").FocusElementType;


/**
 * If a touch move or touch end events happens within this time frame after the
 * touch start event, don't consider it for the context menu.
 */
var HOLD_DELAY = 50;


var CSSInserted = false;
var insertCSS = function() {
  if (CSSInserted) return;
  var root = (document.head || document.body);
  if (root != null) {
    // TODO: What about Content Security Policy?
    var style = document.createElement("style");
    style.appendChild(document.createTextNode(
      "img { -webkit-user-select: none; }" +
      "body { -webkit-touch-callout: none; }" +
      "[__opera-highlight] {" +
        "background-color: rgba(0, 0, 0, 0.25) !important;" +
        "border-radius: 2px !important;" +
      "}"));
    root.appendChild(style);
    CSSInserted = true;
  }
};


var isElement = function(elem) {
  return elem != null && elem.nodeType === Element.prototype.ELEMENT_NODE;
};


/*
 * Is an element that a user would be able to enter text into?
 * Use this instead of checking for <code>type=text</code> for compatibility
 * with HTML5 form inputs.
 */
var isTextLikeInput = function (elem) {
  if (!isElement(elem)) return false;
  var tag = elem.tagName.toLowerCase();
  if (tag === "textarea") return true;
  var types = ["email", "file", "password", "search", "tel", "text", "url"];
  return tag === "input" && types.indexOf(elem.type.toLowerCase()) > -1;
};


var getAncestorByTagName = function (elem, tag) {
  if (!isElement(elem)) return;
  tag = tag.toLowerCase();
  var parent = elem.parentNode;
  while (parent &&
      (parent.tagName == null || parent.tagName.toLowerCase() !== tag)) {
    parent = parent.parentNode;
  }
  return parent;
};


var getFormElementValue = function (elem) {
  var tag = elem.tagName.toLowerCase();
  if (tag === "select") {
    return Array.prototype.map.call(elem["selectedOptions"], function(opt) {
      return opt["value"];
    });
  }
  var type = elem.type && elem.type.toLowerCase();
  if (type === "checkbox" || type === "radio") {
    return elem.checked;
  }
  return elem.value;
};


var serializeForm = function (form) {
  var serialized = {};
  if (isElement(form) || form.elements == null) return serialized;
  var elems = form.elements;
  for (var i = 0, l = elems.length, elem, name, value; i < l; i++) {
    elem = elems[i];
    name = elem.name;
    if (!name) continue;
    value = getFormElementValue(elem);
    if (!value) continue;
    serialized[name] = value;
  }
  return serialized;
};


var toQueryParam = function(prop, val) {
  if (val == null) return "";
  return encodeURIComponent(prop) + "=" + encodeURIComponent(val);
};


// If value is an array, it gets expanded to multiple query parameters.
var toQueryString = function (params) {
  var vals, queries = [];
  for (var prop in params) {
    if (!params.hasOwnProperty(prop)) continue;
    vals = Array.isArray(params[prop]) ? params[prop] : [ params[prop] ];
    queries = queries.concat(
      vals.map(toQueryParam.bind(null, prop))
    );
  }
  return queries.length > 0 ? "?" + queries.join("&") : "";
};


var getElementContent = function (elem) {
  if (!isElement(elem)) return "";
  if (isTextLikeInput(elem) && elem.type.toLowerCase() !== "password") {
    return elem.value;
  }
  return elem.textContent;
};


var getElementFormMethod = function (elem) {
  if (!isElement(elem)) return "";
  if (elem.form != null) return elem.form.method;
};


var getElementHref = function (elem) {
  if (!isElement(elem)) return "";
  if (elem.tagName.toLowerCase() === "a") return elem.href;

  var link = getAncestorByTagName(elem, "a");
  if (link != null) {
    return link.href;
  }
  return "";
};


/*
 * Get a "search engine" string with all form elements as query parameters and
 * the current element's value replaced with %s.
 */
var getElementSearchQuery = function (elem) {
  if (!isElement(elem)) return "";
  var tag = elem.tagName.toLowerCase();
  var type = elem.type ? elem.type.toLowerCase() : "";
  if (tag === "input" && (type === "text" || type === "search") &&
      elem.form && elem.form.enctype === "application/x-www-form-urlencoded") {
    var action = elem.form.action || location.href.split("?")[0].split("#")[0];
    var formData = serializeForm(elem.form);
    var inputName = elem.name || elem.id;
    // Remove search input value, add it later unescaped
    delete formData[inputName];
    var queries = toQueryString(formData);
    queries += (queries.length === 0 ? "?" : "&") + inputName + "=%s";
    return action + queries;
  }
};


/*
 * Get the FocusElementType as defined in FocusElement.h
 */
var getElementType = function (elem) {
  var focusType = FocusElementType.FocusElementTypeDefault;
  if (!isElement(elem)) return focusType;

  var tag = elem.tagName.toLowerCase();

  if (tag === "img") {
    var link = getAncestorByTagName(elem, "a");
    focusType = link ? FocusElementType.FocusElementTypeLinkImage
                     : FocusElementType.FocusElementTypeImage;

  } else if (tag === "input") {
    var type = elem.type ? elem.type.toLowerCase() : "";
    if (type === "password") {
      focusType = FocusElementType.FocusElementTypeInputPassword;
    } else if (type === "file") {
      focusType = FocusElementType.FocusElementTypeInputFile;
    } else if ((type === "text" || type === "search") && elem.form &&
      // default enctype, to distinguish from file upload forms
      elem.form.enctype === "application/x-www-form-urlencoded") {
      focusType = FocusElementType.FocusElementTypeInputSearch;
    } else if (isTextLikeInput(elem)) {
      focusType = FocusElementType.FocusElementTypeInputText;
    }
    if (elem.readOnly || elem.disabled) {
      focusType = focusType | FocusElementType.FocusElementTypeFlagReadOnly;
    }

  } else if (tag === "textarea") {
    focusType = FocusElementType.FocusElementTypeTextarea;
    if (elem.readOnly || elem.disabled) {
      focusType = focusType | FocusElementType.FocusElementTypeFlagReadOnly;
    }

  } else if (tag === "a" || getAncestorByTagName(elem, "a") != null) {
    focusType = FocusElementType.FocusElementTypeLink;
  }

  return focusType;
};


/*
 * Return a CGRect compatible string of the element, adjusted to the current
 * zoom level.
 */
var getElementRect = function(elem) {
  if (!isElement(elem)) return "";
  return elem.getBoundingClientRect();
};


var getElementSrc = function(elem) {
  if (isElement(elem) && elem.tagName.toLowerCase() === "img") {
    return elem.src;
  }
  return "";
};


var hasElementFocus = function(elem) {
  return isTextLikeInput(elem) &&
    (elem.webkitMatchesSelector(":focus") || elem === document.activeElement);
};


/**
 * The last touched element. In the top frame, it will be modified directly
 * by the public API methods. In sub-frames, it will be modified after receiving
 * a message via the postMessage API.
 */
var focusElem = null;

var methods = {

  /**
   * Set the value of the active element.
   *
   * @param {string} val
   */
  setValue: function(val) {
    if (val == null || !isTextLikeInput(focusElem)) return;
    if (focusElem.tagName.toLowerCase() !== "textarea") {
      val = val.replace(/(\r\n|\n|\r)/gm, " ");
    }
    // Insert after selection/caret and update caret position
    if (focusElem.webkitMatchesSelector(":focus")) {
      var pos = focusElem.selectionStart;
      var left = (focusElem.value).substring(0, pos);
      var right = (focusElem.value).substring(pos, focusElem.value.length);
      focusElem.value = left + val + right;
      focusElem.selectionStart = focusElem.selectionEnd = pos + val.length;
    } else {
      focusElem.value = val;
    }
  },

  /**
   * Visually highlight the active element.
   *
   * @param {string} val
   */
  highlight: function() {
    insertCSS();
    focusElem.setAttribute("__opera-highlight", "1");
  },

  /**
   * Reset highlight and selection.
   *
   * @param {string} val
   */
  reset: function() {
    if (focusElem != null) {
      focusElem.removeAttribute("__opera-highlight");
      focusElem = null;
      window.getSelection().collapse();
    }
  }

};


// Execute a mutating method on focusElem.
var execAction = function(action) {
  var method = action["method"];
  if (method && methods[method]) {
    methods[method].apply(null, action["args"] || []);
  }
};


/**
 * Properties of the last active element, only used in the top frame.
 * If a touch originated in the top frame, this will contain cached values of
 * any accessor methods. Otherwise it will contain the values received from the
 * touch event's frame.
 */
var lastAction = {};


/** @expose */
ContextMenu.getContent = function() {
  if (lastAction["content"]) return lastAction["content"];
  lastAction["content"] = getElementContent(focusElem);
  return lastAction["content"];
};


/** @expose */
ContextMenu.getFocusType = function() {
  if (lastAction["focusType"]) return lastAction["focusType"];
  lastAction["focusType"] = getElementType(focusElem);
  return lastAction["focusType"];
};


/** @expose */
ContextMenu.getFormMethod = function() {
  if (lastAction["formMethod"]) return lastAction["formMethod"];
  lastAction["formMethod"] = getElementFormMethod(focusElem);
  return lastAction["formMethod"];
};


/** @expose */
ContextMenu.getHref = function () {
  if (lastAction["href"]) return lastAction["href"];
  lastAction["href"] = getElementHref(focusElem);
  return lastAction["href"];
};


/** @expose */
ContextMenu.getSearchQuery = function () {
  if (lastAction["searchQuery"]) return lastAction["searchQuery"];
  lastAction["searchQuery"] = getElementSearchQuery(focusElem);
  return lastAction["searchQuery"];
};


/** @expose */
ContextMenu.getSrc = function () {
  if (lastAction["src"]) return lastAction["src"];
  lastAction["src"] = getElementSrc(focusElem);
  return lastAction["src"];
};


/** @expose */
ContextMenu.getRect = function (webViewFrameWidth) {
  function CGRectFromRect(rect) {
    // There is a bug where values are not updated in UIWebView on view's frame change.
    // To workaround it we have to pass the width of the UIWebView from the native code to js.
    if (!rect) return "";
    var zoom = webViewFrameWidth / window.innerWidth;
    return "{{" + (rect.left * zoom) + "," + (rect.top * zoom) + "}," +
        "{" + (rect.width * zoom)+ "," + (rect.height * zoom) + "}}";
  }
  if (lastAction["rect"]) return CGRectFromRect(lastAction["rect"]);
  lastAction["rect"] = getElementRect(focusElem);
  return CGRectFromRect(lastAction["rect"]);
};


/** @expose */
ContextMenu.hasFocus = function () {
  if (lastAction["isFocused"]) return lastAction["isFocused"];
  lastAction["isFocused"] = hasElementFocus(focusElem);
  return lastAction["isFocused"];
};


/** @expose */
ContextMenu.setValue = function(value) {
  var action = {
    "args": [ value ],
    "method": "setValue"
  };
  if (focusElem == null) {
    lastAction.window.postMessage(
      { "operaAction": { "type": "callback", "data": action } },
      lastAction.origin
    );
  } else {
    execAction(action);
  }
};


/** @expose */
ContextMenu.highlight = function () {
  var action = {
    "method": "highlight"
  };
  if (focusElem == null) {
    lastAction.window.postMessage(
      { "operaAction": { "type": "callback", "data": action } },
      lastAction.origin
    );
  } else {
    execAction(action);
  }
};


/** @expose */
ContextMenu.reset = function () {
  var action = {
    "method": "reset"
  };
  if (focusElem == null) {
    lastAction.window.postMessage(
      { "operaAction": { "type": "callback", "data": action } },
      lastAction.origin
    );
  } else {
    execAction(action);
  }
};


var isPressing = false, onMessage, onTouchStart;

if (window === window.top) {

  onMessage = function(evt) {
    var action = evt.data["operaAction"];
    if (action == null || action["type"] !== "save") return;
    // Prevent the page's own listeners from being called.
    evt.stopImmediatePropagation();
    DEBUG && console.log("window.top#operaAction", action);
    focusElem = null;
    lastAction = action["data"];
    lastAction["origin"] = evt.origin;
    lastAction["window"] = evt.source;
  };

  // In the top frame, actions are handled directly in the ContextMenu methods.
  onTouchStart = function(evt) {
    isPressing = true;
    setTimeout(function() {
      if (isPressing) {
        lastAction = {};
        focusElem = evt.target;
        isPressing = false;
      }
    }, HOLD_DELAY);
  };

} else {

  onMessage = function(evt) {
    var action = evt.data["operaAction"];
    if (action == null || action.type !== "callback") return;
    // Prevent the page's own listeners from being called.
    evt.stopImmediatePropagation();
    DEBUG && console.log("frame#operaAction", action);
    execAction(action.data);
  };

  // Send all data about the touched element to the top (UIWebView) frame, to
  // enable synchronous access to the data.
  onTouchStart = function(evt) {
    isPressing = true;
    setTimeout(function() {
      if (isPressing) {
        focusElem = evt.target;
        var action = {
          "operaAction": {
            "type": "save",
            "data": {
              "content": getElementContent(focusElem),
              "focusType": getElementType(focusElem),
              "formMethod": getElementFormMethod(focusElem),
              "href": getElementHref(focusElem),
              "isFocused": hasElementFocus(focusElem),
              "rect": getElementRect(focusElem),
              "searchQuery": getElementSearchQuery(focusElem),
              "src": getElementSrc(focusElem)
            }
          }
        };
        window.top.postMessage(action, "*");
        lastAction = {};
        focusElem = evt.target;
        isPressing = false;
      }
    }, HOLD_DELAY);
  };

}

window.addEventListener("message", onMessage);
window.addEventListener("touchstart", onTouchStart);
window.addEventListener("touchend", function() { isPressing = false; });
window.addEventListener("touchmove", function() { isPressing = false; });
